<div class="col-sm-12">
				<p class="back-link">EM Expense Tracker <a href="https://engribrahim.com">Ibrahim Khalil</a></p>
			</div>